# Banking System (CSE202 OOAD with Java)

JavaFX desktop banking application: customers (individuals and organisations) register, open
Savings / Investment / Cheque accounts, deposit, withdraw, view history; monthly interest runs
through the System Scheduler.

## Layers
- `com.bank.model`      domain classes (Customer, Account, Transaction, InterestPayment ...)
- `com.bank.view`       JavaFX boundary classes (no business logic)
- `com.bank.controller` controllers between views and model
- `com.bank.dao`        JDBC data access classes

## Requirements
- Java 21
- Maven 3.9+
- JavaFX 21 (downloaded by Maven)
- H2 2.2.224 (embedded database, downloaded by Maven)

## Build and run
    mvn clean compile
    mvn javafx:run

In GitHub Codespaces JavaFX needs the desktop-lite feature (see `.devcontainer/devcontainer.json`)
and port 6080 to view the window.

## Quick check of the business rules (no Maven needed)
    javac -d out src/main/java/com/bank/model/*.java src/test/java/com/bank/model/ModelSmokeTest.java
    java -cp out com.bank.model.ModelSmokeTest

## Database
`src/main/resources/schema.sql` creates the tables.

TODO: unique constraints on username, id_number and registration_number are in the schema;
make the registration controller check them first and show a friendly message (FR19).
